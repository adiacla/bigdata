# segmentation > 2025-03-26 2:34pm
https://universe.roboflow.com/cicatriz/segmentation-8ybb0-xoye8

Provided by a Roboflow user
License: Public Domain

